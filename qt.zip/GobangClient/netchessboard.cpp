#include "netchessboard.h"

NetChessBoard::NetChessBoard()
{

}
